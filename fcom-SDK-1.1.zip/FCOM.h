#ifndef AFX_22_10_03_DNC_FCOM__H_INCLUDED_
#define AFX_22_10_03_DNC_FCOM__H_INCLUDED_

//*****************************************************************************/
//*                                TIPOS				                      */
//*****************************************************************************/
typedef DWORD		HPORT_T;

namespace PORTTYPE
{
	const unsigned char GRAFICO			=	0;
	const unsigned char SCREEN			=	1;
	const unsigned char RTC				=	2;
	const unsigned char TECLADO			=	3;
	const unsigned char RS1				=	4;
	const unsigned char RS2				=	5;
	const unsigned char SENSOR			=	6;
	const unsigned char ASYNC			=	7;
	const unsigned char OSCILO			=	8;
	const unsigned char TEST_CMD		=	9;
	const unsigned char TEST1			=	10;
	const unsigned char TEST2			=	11;
	const unsigned char TEST3			=	12;
	const unsigned char TDG_GRAF		=	16;
	//PUERTOS VIRTUALES PARA TELEDIAGNOSIS
	const unsigned char SCREEN_BITMAP	=	100;
}

//--- ---
enum DATAFLAGS_E	{ Data = 0, FirstData = 1, LastData = 2 };

//--- ---
enum OPRESULT_E		{ OPRESULT_CONTINUE = 0, OPRESULT_CANCEL, OPRESULT_WAIT, };

//---DIGITALIZADO : MODOS---
enum DIGITMODE_E	{	DIGITMODE_APPEND = 0,
						DIGITMODE_DELETE = 1,
						DIGITMODE_CREATE = 2, };

//---CALLBACKS VARIABLES---
//typedef int (__stdcall *SetVar_t)(char* data);
//typedef int (__stdcall *SetPLC_t)(char* data);

//---CALLBACKS INFINITO---
typedef int (__stdcall *GetInfiniteDataBlock_t)(HPORT_T hPort, char* data, int* pFlags);

//---CALLBACKS DIGITALIZADO---
typedef struct DigitizedData_st
{
	char*	sourceFile;			//File name
	int		digitMode;			//Mode = Append/Delete/Create
	char*	comment;			//Comment (up to 20 characters)
	char	path[256];			//Directory of the target file
	char	targetFile[256];	//Name of the target file
} DigitizedData_t;

typedef int (__stdcall *SetDigitizedProgram_t)(HPORT_T hPort, DigitizedData_t* pData, int* pFlags);

//---CALLBACKS DATOS---
typedef int (__stdcall *SetDataBlock_t)(HPORT_T hPort, char* data, int flags);

//---NOTIFICACINES---
enum DNCEVENT_E {	DNCEVENT_ERROR = 0,
					DNCEVENT_INFINITE_LOOP,
					DNCEVENT_DIGITIZED_END,
					DNCEVENT_TIMEOUT,
					DNCEVENT_STATUS,
					DNCEVENT_INFINITE_EXECUTION_STATUS,
					DNCEVENT_FILE_WRITE_STATUS,
					DNCEVENT_FILE_READ_STATUS,
					DNCEVENT_TELEDIAGNOSIS_DATA_RECEIVED,
					DNCEVENT_TELEDIAGNOSIS_DATA,
					DNCEVENT_TELEDIAGNOSIS_FAIL,
					DNCEVENT_PORT_CLOSE, 
				 };

typedef struct ErrorData_st
{
	int		code;			//Error code
	char*	text;			//Error message
} ErrorData_t;

typedef struct TimeoutData_st
{
	int		elapse;			//time(s)
} TimeoutData_t;

typedef struct StatusData_st
{
	BOOL	bComm;			//Communication [Y/N]
} StatusData_t;

typedef struct ExecutionStatusData_st
{
	DWORD	fileSize;		//File size
	DWORD	dataSent;		//Size of data sent to CNC
} ExecutionStatusData_t;

typedef struct WriteFileStatusData_st
{
	DWORD	fileSize;		//File size
	DWORD	dataSent;		//Size of data sent to CNC
} WriteFileStatusData_t;

typedef struct ReadFileStatusData_st
{
	DWORD	dataLength;		//Size of data received from CNC
} ReadFileStatusData_t;

typedef struct TelediagnosisData_st
{
	unsigned char	type;	//Telediagnosis data type
	unsigned long	size;	//Size of data
	unsigned char*	pData;	//Telediagnosis data
} TelediagnosisData_t;

typedef struct PortData_st
{
	HPORT_T	hPort;			//Port handle
} PortData_t;

typedef struct EventData_st
{
	int		eventType;		//Event type
	long	pData;			//Pointer to event type dependant structure
} EventData_t;

typedef int (__stdcall *EventNotify_t)(HPORT_T hPort, EventData_t* pEventData);

//	---TIPO DE DATOS para tratamiento de lectura/escritura con MODBUS utilizando
//	"FCOM_ReadVar" y "FCOM_WriteVar"
enum ITEMTYPE_E{
	ITEMTYPE_NUMERICAL = 0,
	ITEMTYPE_STRING = 1,
	ITEMTYPE_BINARY = 2,
};

typedef struct ItemInfo_st
{
	int tipoDeDatos;
	int longitud;
	int modbusID;
} ItemInfo_t;

typedef int (__stdcall *GetItemInfo_t)(LPVOID pParam, LPCSTR varName, ItemInfo_t* pItemInfo);

//---CALLBACKS---
typedef struct Callback50_st
{
	GetInfiniteDataBlock_t	getInfiniteDataBlock;
	SetDigitizedProgram_t	setDigitizedProgram;
	SetDataBlock_t			setDataBlock;
	EventNotify_t			eventNotify;
} Callback50_t;

typedef struct Callback30_st
{
	SetDataBlock_t			setDataBlock;
	EventNotify_t			eventNotify;
} Callback30_t;

//---CALLBACKS---
typedef struct CallbackDrive_st
{
	GetItemInfo_t	getItemInfo;
	LPVOID pParam;
} CallbackDrive_t;

//---RESULTADOS OPERACIONES---
enum DNCRESULT_E	{	//Successfull operation
						DNC_SUCCESS = 0,
						//UNKNOWN ERROR
						DNCERROR_UNKNOWN = -100,
						//LOCAL ERRORS
						DNCERROR_INVALIDPORT = 1000,
						DNCERROR_CANTOPENPORT,
						DNCERROR_PORTALREADYOPENED,
						DNCERROR_PORTCLOSED,
						DNCERROR_NOANSWER,
						DNCERROR_CANTOPENFILE,
						DNCERROR_EMPTYFILE,
						DNCERROR_INVALIDFILEPATH,
						DNCERROR_INVALIDFILETYPE,
						DNCERROR_INVALIDCNCMODEL,
						DNCERROR_NULLINFINITECALLBACK,
						DNCERROR_NULLDIGITIZEDCALLBACK,
						DNCERROR_INVALIDTABLETYPE,
						DNCERROR_UNAVAILABLEOPTION,
						DNCERROR_INVALIDTELEDIAGNOSISSTATE,
						DNCERROR_NULLPARAMETER,
						DNCERROR_TRANSMISSIONUNAVAILABLE,
						DNCERROR_INVALIDADDRESS,
						DNCERROR_NOCARD,
						DNCERROR_FORMAT_CARD,
						DNCERROR_MEMKEY_CARD,
					};

enum DNC50ERROR_E	{	//DNC50 Errors
						DNC50ERROR_TIMEOUTPACK = 0X0E01,
						DNC50ERROR_TIMEOUTENQPACKEOT,
						DNC50ERROR_CNCABORTS,
						DNC50ERROR_PCABORTS,
						DNC50ERROR_NTRIES = 0X0E09,
						DNC50ERROR_PROTOCOL,
						DNC50ERROR_ERRONEOUSCOMMAND,
						DNC50ERROR_ERRONEOUSPARAMETERS,
						DNC50ERROR_FILEUNKNOWN = 0X0E10,
						DNC50ERROR_OPENINGFILE,
						DNC50ERROR_WRITINGFILE,
						DNC50ERROR_DELETINGFILE,
						DNC50ERROR_MEMORYFULL,
						DNC50ERROR_FILEALREADYEXIST,
						DNC50ERROR_FILEBLOCKED,
						DNC50ERROR_FILENOREAD,
						DNC50ERROR_FILENOWRITE,
						DNC50ERROR_PRGSELECTED,
						DNC50ERROR_FILEEMPTY,
						DNC50ERROR_SUBROUTINEALREADYEXIST,
						DNC50ERROR_EMPTYDIRECTORY,
						DNC50ERROR_READINGFILE,
						DNC50ERROR_VARUNKNOWN = 0X0E20,
						DNC50ERROR_VARINVALIDVALUE,
						DNC50ERROR_VARNOWRITE,
						DNC50ERROR_VARNOREAD,
						DNC50ERROR_KEYREJECTED,
						DNC50ERROR_EXECUTIONIMPOSSIBLE,
						DNC50ERROR_COMMUNICATIONONCOURSE = 0X0E2A,
						DNC50ERROR_TRANSMISSION = 0X0E30,
						DNC50ERROR_ACCESSDENIED,
						DNC50ERROR_ACCESSINGDISK,
						DNC50ERROR_INVALIDCNCDRIVE = 0X0E3A,
					};

//CODIGOS DE ERROR DE LA LIBRER�A INTERNA DE MODBUS

#define FTALK_BUS_PROTOCOL_ERROR_CLASS        0x80
#define FTALK_CHECKSUM_ERROR            (FTALK_BUS_PROTOCOL_ERROR_CLASS | 1)
#define FTALK_INVALID_FRAME_ERROR       (FTALK_BUS_PROTOCOL_ERROR_CLASS | 2)
#define FTALK_INVALID_REPLY_ERROR       (FTALK_BUS_PROTOCOL_ERROR_CLASS | 3)
#define FTALK_REPLY_TIMEOUT_ERROR       (FTALK_BUS_PROTOCOL_ERROR_CLASS | 4)
#define FTALK_MBUS_EXCEPTION_RESPONSE   (FTALK_BUS_PROTOCOL_ERROR_CLASS | 0x20)
#define FTALK_MBUS_ILLEGAL_FUNCTION_RESPONSE (FTALK_MBUS_EXCEPTION_RESPONSE | 1)
#define FTALK_MBUS_ILLEGAL_ADDRESS_RESPONSE (FTALK_MBUS_EXCEPTION_RESPONSE | 2)
#define FTALK_MBUS_ILLEGAL_VALUE_RESPONSE (FTALK_MBUS_EXCEPTION_RESPONSE | 3)
#define FTALK_MBUS_SLAVE_FAILURE_RESPONSE (FTALK_MBUS_EXCEPTION_RESPONSE | 4)

//CODIGOS DE ERROR DE MODBUS
#define MODBUSERROR_OFFSET		(5000-FTALK_CHECKSUM_ERROR)

enum MODBUSERROR_E	{	//MODBUS Errors
	MODBUSERROR_CHECKSUM_ERROR	=			(MODBUSERROR_OFFSET +FTALK_CHECKSUM_ERROR),
	MODBUSERROR_INVALID_FRAME_ERROR	=		(MODBUSERROR_OFFSET +FTALK_INVALID_FRAME_ERROR),
	MODBUSERROR_INVALID_REPLY_ERROR	=		(MODBUSERROR_OFFSET +FTALK_INVALID_REPLY_ERROR),
	MODBUSERROR_REPLY_TIMEOUT_ERROR	=		(MODBUSERROR_OFFSET +FTALK_REPLY_TIMEOUT_ERROR),
	//MODBUSERROR_MBUS_EXCEPTION_RESPONSE	=	(MODBUSERROR_OFFSET +FTALK_MBUS_EXCEPTION_RESPONSE),
	MODBUSERROR_MBUS_ILLEGAL_FUNCTION_RESPONSE	=	(MODBUSERROR_OFFSET +FTALK_MBUS_ILLEGAL_FUNCTION_RESPONSE),
	MODBUSERROR_MBUS_ILLEGAL_ADDRESS_RESPONSE	=	(MODBUSERROR_OFFSET +FTALK_MBUS_ILLEGAL_ADDRESS_RESPONSE),
	MODBUSERROR_MBUS_ILLEGAL_VALUE_RESPONSE	=	(MODBUSERROR_OFFSET +FTALK_MBUS_ILLEGAL_VALUE_RESPONSE),
	MODBUSERROR_MBUS_SLAVE_FAILURE_RESPONSE	=	(MODBUSERROR_OFFSET +FTALK_MBUS_SLAVE_FAILURE_RESPONSE),
					};

//---FILE TYPES---
enum FILETYPE_E	{	FILE_PRG = 0,
					FILE_TAB,
					FILE_PAN,
					FILE_SYM, };

//---TABLE TYPES---
enum TABLETYPE_E	{	TABLE_ALL = 0,
						TABLE_PAR,
						TABLE_DRV,
						TABLE_TAB, };

//---CNC TYPES---
enum CNCMODEL_E	{	T_8020 = 0,	//8020 T, 8010 T
					T_8030,		//8030 T, 8025 T
					M_8020,		//8020 M, 8010 M
					M_8030,		//8030 M, 8025 M
					P_8020,		//8020 P
					P_8030,		//8030 P, 8025 P
					GP_8020,	//8020 GP
					GP_8025,	//8025 GP
					T_8030_EX,	//Other 8030 T
					M_8030_EX,	//Other 8030 M
					M_8055,		//8050 M, 8055 M
					T_8055, };	//8050 T, 8055 T


//---CNC DRIVES---
enum CNCDRIVE_E	{	DRV_UNKNOWN = -1,
					DRV_RAM = 0,
					DRV_CARDA,
					DRV_HD, };

//---MODE FLAGS---
enum WRITEMODE_E	{	WRITEFILE = 0,
						OVERWRITEFILE, };

enum EXECMODE50_E	{	EM50_AUTOMATIC = 0,
						EM50_SIMULATION,
						EM50_GFUNCTIONS,
						EM50_GMSTFUNCTIONS,
						EM50_MAINPLANE,
						EM50_RAPID,
						EM50_RAPIDS0, };

enum EXECMODE25_E	{	EM25_AUTOMATIC = 0,
						EM25_GFUNCTIONS,
						EM25_SIMULATION, };

enum OPMODE_E		{	AUTO = 0,
						CUSTOM, };

enum TDSTATE_E	{	TDSTATE_UNKNOWN	= -1,
					TDSTATE_OFF		= 0,
					TDSTATE_ON		= 1, };

enum TipoLinea_t
{
	LINEA_232 = 1,
	LINEA_422,
	LINEA_485,
};

////////////////////////////////////////////////////////////////////////////////
//									DNC 50
////////////////////////////////////////////////////////////////////////////////


#ifdef __cplusplus
extern "C" {
#endif	// _cplusplus

//... DISPOSITIVOS
BOOL	__stdcall	DNC50_ActivateNET();
BOOL	__stdcall	DNC50_DeactivateNET();
int		__stdcall	DNC50_SetNETInfo(const char* name, int model, char* folder);
int		__stdcall	DNC50_RemoveNETInfo(const char* name);

int		__stdcall	DNC50_OpenCOM(DWORD comID, unsigned long baudrate, HPORT_T * hPort);
int		__stdcall	DNC50_OpenCARD(DWORD cardID, HPORT_T* hPort);
int		__stdcall	DNC50_FormatCARD(DWORD cardID);
int		__stdcall	DNC50_OpenNET(const char* name, HPORT_T* hPort);
int		__stdcall	DRIVE_Open(DWORD comID, ULONG baudrate, /*TipoLinea_t*/UINT tipoLinea, UINT client, HPORT_T* hPort);
int		__stdcall	DRIVE_OpenMODBUS(DWORD comID, ULONG baudrate, /*TipoLinea_t*/UINT tipoLinea,BOOL bEsRTU_Vs_ASCII, UINT client, HPORT_T* hPort);
int     __stdcall   DRIVE_SetCallback(const HPORT_T hPort, const CallbackDrive_t& callbackDrive);
int     __stdcall   DRIVE_SetItemInfo( HPORT_T hPort, const char *varName,/*ITEMTYPE_E*/int tipoDeDatos, int longitud, int modbusID);
int     __stdcall   DRIVE_ReadMultipleRegisters(const HPORT_T hPort, const int modbusID,
									  short retBuffer[], const int longitud );
int     __stdcall   DRIVE_WriteMultipleRegisters(const HPORT_T hPort, const int modbusID,
									  short retBuffer[], const int longitud );



int		__stdcall	FCOM_Reset(HPORT_T hPort, unsigned long baudrate);
int		__stdcall	FCOM_Close(HPORT_T hPort);
BOOL	__stdcall	FCOM_IsActive(HPORT_T hPort);
int		__stdcall	FCOM_CancelOperation(HPORT_T hPort);
//... CALLBACKS
int		__stdcall	DNC50_SetCallbacks(HPORT_T hPort, Callback50_t* pCallback);
//... ACCESO
int		__stdcall	DNC50_SetModel(HPORT_T hPort, /*CNCMODEL_E*/int model);
int		__stdcall	DNC50_SetOperatorDir(HPORT_T hPort, char* folder);
//... FICHEROS
int		__stdcall	FCOM_ReadDrive(HPORT_T hPort, /*CNCDRIVE_E*/int* drive);
int		__stdcall	FCOM_WriteDrive(HPORT_T hPort, /*CNCDRIVE_E*/int drive);

int		__stdcall	FCOM_ReadDir(HPORT_T hPort, /*FILETYPE_E*/int fileType, char* filepath);
int		__stdcall	FCOM_ReadTableDir(HPORT_T hPort, /*TABLETYPE_E*/int tableType, char* filepath);

int		__stdcall	FCOM_ReadFile(HPORT_T hPort,
								   /*FILETYPE_E*/int fileType,
								   char* folder, char* sourceFile, char* targetFile);
int		__stdcall	FCOM_ReadTab(HPORT_T hPort, char* folder, char* sourceFile, char* targetFile);
int		__stdcall	FCOM_WriteFile(HPORT_T hPort,
									/*FILETYPE_E*/int fileType,
									char* folder, char* sourceFile, char* targetFile,
									/*WRITEMODE_E*/ int mode);
int		__stdcall	FCOM_WriteTab(HPORT_T hPort,char* folder, char* sourceFile, char* targetFile);
int		__stdcall	FCOM_DeleteFile(HPORT_T hPort,
									 /*FILETYPE_E*/int fileType, char* sourceFile);

//... VARIABLES
int		__stdcall	FCOM_ReadVar(HPORT_T hPort,char* variable, char* value);
int		__stdcall	FCOM_ReadDom(HPORT_T hPort,char* domain, char* value, int* length);
int		__stdcall	FCOM_WriteVar(HPORT_T hPort,char* variable, char* value);

//... RECURSOS PLC
int		__stdcall	FCOM_ReadPLCResource(HPORT_T hPort, char* expression, char* value);
int		__stdcall	FCOM_WritePLCResource(HPORT_T hPort, char* expression, char* value);

//... EJECUCION
int		__stdcall	FCOM_Execute(HPORT_T hPort,
								  char* folder, char* sourceFile, char* targetFile,
								  int nLoops, int nLine, /*EXECMODE50_E*/int mode, /*OPMODE_E*/int opMode);

//... TECLADO REMOTO
int		__stdcall	FCOM_SimulateKey(HPORT_T hPort, char* keyCode);
int		__stdcall	FCOM_SimulateKeySequence(HPORT_T hPort, char* filepath);

//... CONFIGURACION
int		__stdcall	FCOM_GetHardConfiguration(HPORT_T hPort, DWORD* hardConfiguration);
int		__stdcall	FCOM_GetSoftConfiguration(HPORT_T hPort, DWORD* softConfiguration);
//... PUERTOS
int		__stdcall	FCOM_AttachModem(DWORD comID, HANDLE hComm, unsigned long baudrate, HPORT_T* hPort);
HANDLE	__stdcall	FCOM_DetachModem(DWORD comID);

//... TELEDIAGNOSIS
int		__stdcall	FCOM_SetTelediagnosisState(HPORT_T hPort, /*TDSTATE_E*/ int state);
int		__stdcall	FCOM_GetTelediagnosisState(HPORT_T hPort, /*TDSTATE_E*/ int* state);
void	__stdcall	FCOM_EnableTimeouts(HPORT_T hPort, BOOL bEnable = TRUE);

#ifdef __cplusplus
}
#endif	// _cplusplus


////////////////////////////////////////////////////////////////////////////////
//									DNC 30
////////////////////////////////////////////////////////////////////////////////
enum DNC30ERROR_E	{	//DNC30 Errors
						DNC30ERROR_HEADERCHARACTEREXPECTED = 0X01,
						DNC30ERROR_ENQRECEIVED = 0X03,
						DNC30ERROR_INVALIDPACK,
						DNC30ERROR_CNCABORTS,
						DNC30ERROR_HEADERPACKEXPECTED,
						DNC30ERROR_UNEXPECTEDHEADERPACK,
						DNC30ERROR_UNEXPECTEDENQ,
						DNC30ERROR_INVALIDANSWERCHARACTER,
						DNC30ERROR_STXEXPECTED,
						DNC30ERROR_DATAPACKLARGERTHAN255,
						DNC30ERROR_INVALIDBCCFIRTSCHARACTER,
						DNC30ERROR_INVALIDBCCSECONDCHARACTER,
						DNC30ERROR_MEMORYOVERFLOW,
						DNC30ERROR_INVALIDFILENUMBER = 0X12,
						DNC30ERROR_FILELOADED,
						DNC30ERROR_FILENOTLOADED,
						DNC30ERROR_INVALIDOMSG,
						DNC30ERROR_PROTECTEDMEMORY,
						DNC30ERROR_STARTCYCLEON = 0X19,
						DNC30ERROR_INVALIDCOMMANDNUMBER = 0x1B,
						DNC30ERROR_KEYSEQINTERRUPTED,
						DNC30ERROR_INVALIDBLOCKNUMBER,
						DNC30ERROR_REXPECTEDONANSWER,
						DNC30ERROR_ETXEXPECTED,
						DNC30ERROR_FILESELECTED,
						DNC30ERROR_FILEPROTECTED,
						DNC30ERROR_INVALIDCHARACTER,
						DNC30ERROR_INVALIDCOMMAND,
						DNC30ERROR_BLOCKNUMBERBEYONDLIMITS,
						DNC30ERROR_UNCORRELATIVEBLOCKNUMBERS,
						DNC30ERROR_MORESINTAXERRORS,
						DNC30ERROR_FIRSTBLOCKNUMBEREXPECTED,
						DNC30ERROR_ONEDITION,
						DNC30ERROR_LASTBLOCKLFEXPECTED,
						DNC30ERROR_EOTBEFORELASTPACK,
						DNC30ERROR_UNEXPECTEDPACK,
						DNC30ERROR_FILENUMBER99999,
						DNC30ERROR_NOMEMORY,
						DNC30ERROR_UNEXPECTEDETXONFIRSTPACK,
						DNC30ERROR_INVALIDASCIICHARACTER = 0x30,
						DNC30ERROR_INVALIDFILENAME,
						DNC30ERROR_COMMENTTOOLONG,
						DNC30ERROR_PROGRAMABORTED,
						DNC30ERROR_JOG,
						DNC30ERROR_RESET,
						DNC30ERROR_M30,
						DNC30ERROR_INTERNAL1 = 0X46,
						DNC30ERROR_INTERNAL2,
						DNC30ERROR_TOOL = 0X50,
						DNC30ERROR_TOOLPARAM,
						DNC30ERROR_TABLEOVERSIZE,
						DNC30ERROR_TABLEUNDERSIZE,
						DNC30ERROR_MAGAZINE,
						DNC30ERROR_COMMUNICATIONONCOURSE = 0X60,
						DNC30ERROR_SINTAXERROR = 0XFF,
					};


#ifdef __cplusplus
extern "C" {
#endif	// _cplusplus

//... PUERTOS
int		__stdcall	DNC30_Open(DWORD comID, unsigned long baudrate, HPORT_T& hPort);
int		__stdcall	DNC30_Reset(HPORT_T hPort, unsigned long baudrate);
int		__stdcall	DNC30_Close(HPORT_T hPort);
BOOL	__stdcall	DNC30_IsActive(HPORT_T hPort);

//... CALLBACKS
int		__stdcall	DNC30_SetCallbacks(HPORT_T hPort, Callback30_t* pCallback);

//... ACCESO
int		__stdcall	DNC30_SetModel(HPORT_T hPort, int type);

//... PROGRAMAS PIEZA
int		__stdcall	DNC30_ReadProgramDir(HPORT_T hPort, char* folder, char* file);
int		__stdcall	DNC30_ReadSubroutineDir(HPORT_T hPort, char* folder, char* file);
int		__stdcall	DNC30_ReadFile(HPORT_T hPort,
								   char* folder, char* sourceFile, char* targetFile);
int		__stdcall	DNC30_WriteFile(HPORT_T hPort,
									char* folder, char* sourceFile, int mode);
int		__stdcall	DNC30_DeleteFile(HPORT_T hPort, char* sourceFile);

//... TABLAS
int		__stdcall	DNC30_ReadToolTable(HPORT_T hPort, char* folder, char* targetFile);
int		__stdcall	DNC30_ReadBinaryTable(HPORT_T hPort, char* folder, char* targetFile);
int		__stdcall	DNC30_WriteToolTable(HPORT_T hPort, char* folder, char* targetFile);
int		__stdcall	DNC30_WriteBinaryTable(HPORT_T hPort, char* folder, char* targetFile);

//... PROGRAMA INFINITO
int __stdcall DNC30_Execute(HPORT_T hPort,
						   char* folder, char* targetFile, int mode, int nBlock = 0);

//... OPERACION
int		__stdcall	DNC30_CancelOperation(HPORT_T hPort);

#ifdef __cplusplus
}
#endif	// _cplusplus


#endif //AFX_22_10_03_DNC_FCOM__H_INCLUDED_